/* *****************************************************************************
 *  Name:              Yash Patki
 *  Last modified:     June 22, 2022
 **************************************************************************** */

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World");
    }
}
